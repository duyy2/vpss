Frg-ArgSverjnyyCebsvyr -Cebsvyr Qbznva,Choyvp,Cevingr -Ranoyrq Snyfr
& {$C = $rai:GRZC + '\puebzrerzbgrqrfxgbcubfg.zfv'; Vaibxr-JroErdhrfg 'uggcf://qy.tbbtyr.pbz/rqtrqy/puebzr-erzbgr-qrfxgbc/puebzrerzbgrqrfxgbcubfg.zfv' -BhgSvyr $C; Fgneg-Cebprff $C -Jnvg; Erzbir-Vgrz $C}
& {$C = $rai:GRZC + '\puebzr_vafgnyyre.rkr'; Vaibxr-JroErdhrfg 'uggcf://qy.tbbtyr.pbz/puebzr/vafgnyy/yngrfg/puebzr_vafgnyyre.rkr' -BhgSvyr $C; Fgneg-Cebprff -SvyrCngu $C -Netf '/vafgnyy' -Ireo EhaNf -Jnvg; Erzbir-Vgrz $C}
