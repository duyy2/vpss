$v = 360
qb {
Jevgr-Ubfg $v
Fyrrc 60
$v--
} juvyr ($v -tg 0)
